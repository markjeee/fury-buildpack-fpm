module Dotenv
  VERSION = "2.5.0".freeze
end
