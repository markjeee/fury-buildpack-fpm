module FPM
  VERSION = "1.10.2"
end
