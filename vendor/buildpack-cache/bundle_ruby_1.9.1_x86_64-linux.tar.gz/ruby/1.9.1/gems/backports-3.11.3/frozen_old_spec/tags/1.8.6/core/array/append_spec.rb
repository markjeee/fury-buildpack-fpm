fails:Array#<< raises a RuntimeError on a frozen array
