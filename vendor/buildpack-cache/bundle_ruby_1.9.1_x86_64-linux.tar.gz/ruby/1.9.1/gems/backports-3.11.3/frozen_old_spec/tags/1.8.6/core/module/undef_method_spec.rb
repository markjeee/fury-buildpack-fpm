fails:Module#undef_method is a private method
