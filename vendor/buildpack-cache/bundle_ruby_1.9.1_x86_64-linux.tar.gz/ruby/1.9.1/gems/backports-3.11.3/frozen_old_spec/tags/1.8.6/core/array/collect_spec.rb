fails:Array#collect returns an Enumerator when no block given
fails:Array#collect does not copy untrusted status
fails:Array#collect! keeps untrusted status
fails:Array#collect! when frozen raises a RuntimeError
fails:Array#collect! when frozen raises a RuntimeError when empty
fails:Array#collect! when frozen raises a RuntimeError when calling #each on the returned Enumerator
fails:Array#collect! when frozen raises a RuntimeError when calling #each on the returned Enumerator when empty
