fails:Module#attr_writer allows for adding an attr_writer to an immediate
fails:Module#attr_writer is a private method
