fails:Module#attr is a private method
