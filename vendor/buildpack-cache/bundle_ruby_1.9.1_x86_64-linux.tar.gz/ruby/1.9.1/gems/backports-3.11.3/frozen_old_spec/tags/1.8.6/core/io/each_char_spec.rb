fails:IO#each_char yields each character
