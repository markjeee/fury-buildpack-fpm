fails:Module#remove_method is a private method
