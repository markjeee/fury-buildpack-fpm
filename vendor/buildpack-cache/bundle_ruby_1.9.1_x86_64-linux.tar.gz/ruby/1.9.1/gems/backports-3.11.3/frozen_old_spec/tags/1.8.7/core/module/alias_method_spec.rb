fails:Module#alias_method raises RuntimeError if frozen
fails:Module#alias_method is a private method
fails:Module#alias_method aliasing special methods keeps initialize private when aliasing
fails:Module#alias_method aliasing special methods keeps initialize_copy private when aliasing
fails:Module#alias_method aliasing special methods keeps initialize_clone private when aliasing
fails:Module#alias_method aliasing special methods keeps initialize_dup private when aliasing
fails:Module#alias_method aliasing special methods keeps respond_to_missing? private when aliasing
