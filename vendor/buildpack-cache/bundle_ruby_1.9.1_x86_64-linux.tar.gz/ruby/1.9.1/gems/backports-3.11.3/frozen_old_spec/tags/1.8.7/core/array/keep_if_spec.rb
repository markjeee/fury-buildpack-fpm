fails:Array#keep_if on frozen objects with truthy block raises a RuntimeError
fails:Array#keep_if on frozen objects with falsy block raises a RuntimeError
