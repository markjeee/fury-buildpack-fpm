fails:Struct.new raises a TypeError if object doesn't respond to to_sym
