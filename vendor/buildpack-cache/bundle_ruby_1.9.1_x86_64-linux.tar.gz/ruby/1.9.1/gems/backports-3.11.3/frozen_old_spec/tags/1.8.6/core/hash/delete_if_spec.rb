fails:Hash#delete_if raises a RuntimeError if called on a frozen instance
