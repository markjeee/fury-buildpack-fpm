fails:Hash#reject! raises a RuntimeError if called on a frozen instance that is modified
fails:Hash#reject! raises a RuntimeError if called on a frozen instance that would not be modified
