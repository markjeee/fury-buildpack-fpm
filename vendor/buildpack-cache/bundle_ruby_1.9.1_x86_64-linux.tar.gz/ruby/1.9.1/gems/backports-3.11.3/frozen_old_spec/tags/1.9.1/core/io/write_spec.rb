fails:IO.write uses encoding from given options, if provided
fails:IO.write uses an :open_args option
