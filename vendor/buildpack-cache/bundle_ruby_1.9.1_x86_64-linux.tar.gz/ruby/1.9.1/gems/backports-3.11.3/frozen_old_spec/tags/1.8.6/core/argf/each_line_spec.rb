fails:ARGF.each_line is a public method
fails:ARGF.each_line requires multiple arguments
fails:ARGF.each_line reads each line of files
fails:ARGF.each_line returns self when passed a block
fails:ARGF.each_line returns an Enumerator when passed no block
fails:ARGF.each_line with a separator yields each separated section of all streams
