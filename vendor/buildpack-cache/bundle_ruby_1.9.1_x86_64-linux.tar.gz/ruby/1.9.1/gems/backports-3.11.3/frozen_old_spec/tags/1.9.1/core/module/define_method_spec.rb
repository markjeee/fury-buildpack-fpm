fails:Module#define_method is private
fails:Module#define_method returns its symbol
fails:Module#define_method method body is an UnboundMethod allows methods defined on a different object
