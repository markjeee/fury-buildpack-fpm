fails:Module#remove_method is a private method
fails:Module#remove_method on frozen instance raises a RuntimeError when passed a name
fails:Module#remove_method on frozen instance raises a RuntimeError when passed a missing name
