fails:File.new raises an Errno::EBADF if the first parameter is an invalid file descriptor
