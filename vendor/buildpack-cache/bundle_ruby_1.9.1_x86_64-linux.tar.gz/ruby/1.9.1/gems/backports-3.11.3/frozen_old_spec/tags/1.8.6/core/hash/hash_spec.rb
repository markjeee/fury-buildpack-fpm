fails:Hash#hash generates a hash for recursive hash structures
fails:Hash#hash returns the same hash for recursive hashes
fails:Hash#hash returns the same hash for recursive hashes through arrays
