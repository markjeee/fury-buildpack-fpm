fails:Enumerable#all? with block gathers initial args as elements when each yields multiple
