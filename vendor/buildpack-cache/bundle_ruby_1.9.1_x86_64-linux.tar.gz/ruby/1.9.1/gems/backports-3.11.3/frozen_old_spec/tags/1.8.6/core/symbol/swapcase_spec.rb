fails:Symbol#swapcase leaves uppercase Unicode characters as they were
fails:Symbol#swapcase leaves lowercase Unicode characters as they were
