fails:IO.write uses encoding from given options, if provided
fails:IO.write uses an :open_args option
fails:IO.write disregards other options if :open_args is given
fails:IO.write uses the given encoding and returns the number of bytes written
fails:IO.write writes binary data if no encoding is given
