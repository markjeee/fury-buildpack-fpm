fails:Proc#yield on a Proc created with Kernel#lambda or Kernel#proc ignores excess arguments when self is a proc
fails:Proc#yield on a Proc created with Kernel#lambda or Kernel#proc substitutes nil for missing arguments when self is a proc
fails:Proc#yield on a Proc created with Kernel#lambda or Kernel#proc raises an ArgumentError on excess arguments when self is a lambda
fails:Proc#yield on a Proc created with Kernel#lambda or Kernel#proc raises an ArgumentError on missing arguments when self is a lambda
