fails:Module#define_method is private
