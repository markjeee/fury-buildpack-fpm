fails:Module#attr_accessor is a private method
