fails:NilClass#dup raises a TypeError
