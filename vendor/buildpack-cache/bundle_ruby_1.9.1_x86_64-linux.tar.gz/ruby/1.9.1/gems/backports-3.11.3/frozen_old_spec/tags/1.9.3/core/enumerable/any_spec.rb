fails:Enumerable#any? raises an ArgumentError when any arguments provided
