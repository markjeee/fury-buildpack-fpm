fails:Enumerable#collect_concat calls to_ary but not to_a
