fails:Module#alias_method is a private method
