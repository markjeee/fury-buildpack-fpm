fails:Array#rotate returns subclass instance for Array subclasses
