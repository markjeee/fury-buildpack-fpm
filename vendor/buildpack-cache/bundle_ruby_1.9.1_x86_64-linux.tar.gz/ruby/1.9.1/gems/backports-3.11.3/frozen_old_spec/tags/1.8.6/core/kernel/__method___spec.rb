fails:Kernel.__method__ returns the original name when aliased method
