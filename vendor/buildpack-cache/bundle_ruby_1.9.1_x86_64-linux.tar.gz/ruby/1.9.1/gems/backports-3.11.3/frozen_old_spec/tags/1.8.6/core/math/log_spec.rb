fails:Math.log raises a TypeError if the argument cannot be coerced with Float()
fails:Math.log raises a TypeError for numerical values passed as string
fails:Math.log returns NaN given NaN
