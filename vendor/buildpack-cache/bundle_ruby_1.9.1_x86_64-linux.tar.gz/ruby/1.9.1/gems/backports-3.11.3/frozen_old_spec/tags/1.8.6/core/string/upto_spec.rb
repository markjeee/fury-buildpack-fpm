fails:String#upto raises a LocalJumpError if other is a string but no block was given
