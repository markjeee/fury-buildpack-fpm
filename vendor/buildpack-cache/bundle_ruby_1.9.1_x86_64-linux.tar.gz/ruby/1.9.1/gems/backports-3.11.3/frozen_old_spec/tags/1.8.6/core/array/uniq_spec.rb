fails:Array#uniq! raises a RuntimeError on a frozen array when the array is modified
fails:Array#uniq! raises a RuntimeError on a frozen array when the array would not be modified
fails:Array#uniq! doesn't yield to the block on a frozen array
