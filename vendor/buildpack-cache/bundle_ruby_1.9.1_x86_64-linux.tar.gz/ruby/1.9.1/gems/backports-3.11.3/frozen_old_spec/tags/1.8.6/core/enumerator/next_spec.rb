fails:Enumerator#next is rewound after encountering a StopIteration
