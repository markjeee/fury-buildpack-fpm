fails:ARGF.each is a public method
fails:ARGF.each requires multiple arguments
fails:ARGF.each reads each line of files
fails:ARGF.each returns self when passed a block
fails:ARGF.each returns an Enumerator when passed no block
fails:ARGF.each with a separator yields each separated section of all streams
