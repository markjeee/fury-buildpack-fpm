fails:Hash#assoc only returns the first matching key-value pair for identity hashes
