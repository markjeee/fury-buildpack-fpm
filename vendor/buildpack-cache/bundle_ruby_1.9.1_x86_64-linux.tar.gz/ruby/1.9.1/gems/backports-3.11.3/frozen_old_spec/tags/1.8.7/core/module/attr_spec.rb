fails:Module#attr is a private method
fails:Module#attr creates a getter but no setter for all given attribute names
