fails:Module#include imports constants to modules and classes
fails:Module#include imports instance methods to modules and classes
fails:Module#include does not import methods to modules and classes
