fails:Enumerable#any? raises an ArgumentError when any arguments provided
fails:Enumerable#any? with block gathers initial args as elements when each yields multiple
