fails:Module#attr_reader is a private method
