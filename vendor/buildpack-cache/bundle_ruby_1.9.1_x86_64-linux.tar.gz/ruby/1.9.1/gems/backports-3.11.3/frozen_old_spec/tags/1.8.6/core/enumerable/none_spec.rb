fails:Enumerable#none? with a block gathers initial args as elements when each yields multiple
