fails:String#rpartition with String affects $~
