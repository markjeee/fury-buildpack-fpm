fails:File.join flattens nested arrays
fails:File.join inserts the separator in between empty strings and arrays
fails:File.join raises an ArgumentError if passed a recursive array
