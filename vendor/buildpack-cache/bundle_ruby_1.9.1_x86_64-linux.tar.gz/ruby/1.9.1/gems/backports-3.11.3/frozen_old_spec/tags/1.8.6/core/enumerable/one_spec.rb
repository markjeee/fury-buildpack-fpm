fails:Enumerable#one? when passed a block gathers initial args as elements when each yields multiple
