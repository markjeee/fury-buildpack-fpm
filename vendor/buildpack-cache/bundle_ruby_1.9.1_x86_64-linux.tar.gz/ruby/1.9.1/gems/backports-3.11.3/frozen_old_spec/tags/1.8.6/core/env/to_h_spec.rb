fails:ENV.to_hash uses the locale encoding for keys
fails:ENV.to_hash uses the locale encoding for values
