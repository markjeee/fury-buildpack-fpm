fails:Struct.new creates a new anonymous class with nil first argument
fails:Struct.new creates a new anonymous class with symbol arguments
fails:Struct.new processes passed block with instance_eval
