fails:Module#define_method is private
fails:Module#define_method returns its symbol
