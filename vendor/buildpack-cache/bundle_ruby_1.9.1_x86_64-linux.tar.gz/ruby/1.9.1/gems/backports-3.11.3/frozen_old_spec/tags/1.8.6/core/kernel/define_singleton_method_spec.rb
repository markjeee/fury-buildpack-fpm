fails:Kernel#define_singleton_method when given an UnboundMethod defines any Child class method from any Parent's class methods
fails:Kernel#define_singleton_method when given an UnboundMethod will raise when attempting to define an object's singleton method from another object's singleton method
