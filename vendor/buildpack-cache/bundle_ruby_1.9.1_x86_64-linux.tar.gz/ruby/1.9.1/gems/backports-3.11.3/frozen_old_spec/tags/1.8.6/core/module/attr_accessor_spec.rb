fails:Module#attr_accessor allows creating an attr_accessor on an immediate class
fails:Module#attr_accessor is a private method
