fails:File#to_path preserves the encoding of the path
