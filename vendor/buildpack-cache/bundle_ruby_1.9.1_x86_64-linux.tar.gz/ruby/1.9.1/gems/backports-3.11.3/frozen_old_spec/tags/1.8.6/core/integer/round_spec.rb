fails:Integer#round raises a RangeError when passed Float::INFINITY
fails:Integer#round raises a RangeError when passed a big negative value
