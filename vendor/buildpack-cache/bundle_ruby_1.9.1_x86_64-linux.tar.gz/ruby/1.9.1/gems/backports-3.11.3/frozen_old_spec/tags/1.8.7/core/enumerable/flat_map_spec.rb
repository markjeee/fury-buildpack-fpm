fails:Enumerable#flat_map calls to_ary but not to_a
