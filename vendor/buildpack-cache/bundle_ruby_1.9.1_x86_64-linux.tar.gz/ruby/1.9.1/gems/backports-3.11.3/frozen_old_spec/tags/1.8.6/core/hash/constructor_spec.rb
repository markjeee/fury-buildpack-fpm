fails:Hash.[] raises an ArgumentError for arrays of more than 2 elements
fails:Hash.[] raises an ArgumentError when passed a list of value-invalid-pairs in an array
fails:Hash.[] removes the default_proc
