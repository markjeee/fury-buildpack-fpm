fails:Module#attr_reader allows for adding an attr_reader to an immediate
fails:Module#attr_reader is a private method
