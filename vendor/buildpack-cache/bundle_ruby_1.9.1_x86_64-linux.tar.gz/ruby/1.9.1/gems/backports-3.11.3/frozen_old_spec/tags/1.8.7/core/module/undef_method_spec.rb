fails:Module#undef_method is a private method
fails:Module#undef_method on frozen instance raises a RuntimeError when passed a name
fails:Module#undef_method on frozen instance raises a RuntimeError when passed a missing name
