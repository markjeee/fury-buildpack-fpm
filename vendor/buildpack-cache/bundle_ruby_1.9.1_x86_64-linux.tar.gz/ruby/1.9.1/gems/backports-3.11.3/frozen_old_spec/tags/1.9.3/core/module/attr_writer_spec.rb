fails:Module#attr_writer is a private method
