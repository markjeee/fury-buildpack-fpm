fails:Symbol#capitalize leaves the first character alone if it is not an alphabetical ASCII character
fails:Symbol#capitalize leaves uppercase Unicode characters as they were
fails:Symbol#capitalize leaves lowercase Unicode characters as they were
