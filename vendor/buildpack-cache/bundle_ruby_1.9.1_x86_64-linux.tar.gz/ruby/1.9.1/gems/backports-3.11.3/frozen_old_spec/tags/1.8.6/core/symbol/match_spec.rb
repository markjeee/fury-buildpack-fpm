fails:Symbol#=~ sets the last match pseudo-variables
fails:Symbol#match sets the last match pseudo-variables
