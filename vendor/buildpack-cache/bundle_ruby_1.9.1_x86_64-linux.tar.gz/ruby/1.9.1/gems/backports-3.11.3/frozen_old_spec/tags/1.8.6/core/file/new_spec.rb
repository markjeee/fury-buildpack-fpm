fails:File.new returns a new File when use File::APPEND mode
fails:File.new returns a new File when use File::RDONLY|File::APPEND mode
