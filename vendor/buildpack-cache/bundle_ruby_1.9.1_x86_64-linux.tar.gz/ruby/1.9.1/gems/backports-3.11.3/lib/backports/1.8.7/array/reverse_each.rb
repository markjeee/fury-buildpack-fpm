require 'backports/tools/make_block_optional'

Backports.make_block_optional Array, :reverse_each, :test_on => [42]
