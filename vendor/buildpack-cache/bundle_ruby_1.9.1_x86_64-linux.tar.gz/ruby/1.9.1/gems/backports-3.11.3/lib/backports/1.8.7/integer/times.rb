require 'backports/tools/make_block_optional'

Backports.make_block_optional Integer, :times, :test_on => 42
