#!/bin/sh
exec autoreconf -v -i
