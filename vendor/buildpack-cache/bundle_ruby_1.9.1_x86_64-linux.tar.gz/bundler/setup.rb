require 'rbconfig'
# ruby 1.8.7 doesn't define RUBY_ENGINE
ruby_engine = defined?(RUBY_ENGINE) ? RUBY_ENGINE : 'ruby'
ruby_version = RbConfig::CONFIG["ruby_version"]
path = File.expand_path('..', __FILE__)
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/rake-12.2.1/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/cabin-0.9.0/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/cabin-0.9.0/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/arr-pm-0.0.10/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/arr-pm-0.0.10/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/backports-3.11.3/lib"
$:.unshift "#{path}/"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/ffi-1.9.25/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/childprocess-0.9.0/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/clamp-1.0.1/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/dotenv-2.5.0/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/json-1.8.6/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/insist-1.0.0/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/insist-1.0.0/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/mustache-0.99.8/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/stud-0.0.23/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/stud-0.0.23/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/pleaserun-0.0.30/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/pleaserun-0.0.30/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/io-like-0.3.0/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/ruby-xz-0.2.3/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/fpm-1.10.2/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/fpm-1.10.2/lib"
$:.unshift "#{path}/../#{ruby_engine}/#{ruby_version}/gems/packguy-0.1.0.alpha.9.gf0b82cc/lib"
